
from predict_no1 import *
import os

def main():
    for i in range(5):
        get_prediction_score(name='bigg1')


if __name__ == "__main__":
    main()
