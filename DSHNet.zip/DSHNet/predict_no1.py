from utils import *
import torch
from DSHconv import dshnet
from tqdm import tqdm
import config
import cobra
from os.path import exists
np.random.seed(6)
args = config.parse()
device = torch.device('cuda:1' if torch.cuda.is_available() else 'cpu')
from sklearn import metrics
from sklearn.metrics import auc,precision_recall_curve
def auprr(prob,gt):
    label = gt
    predict = prob
    # aupr = metrics.average_precision_score(y_true=label, y_score=predict)
    auroc = metrics.roc_auc_score(y_true=label, y_score=predict)
    precision, recall, thresholds = precision_recall_curve(label, predict)
    aupr=auc(recall, precision)
    return aupr, auroc
import numpy as np
def train(G,feature, node_fea,y, incidence_matrix, model, optimizer):
    
    model.train()
    optimizer.zero_grad()
    y_pred = model(G,feature, node_fea,incidence_matrix)
    loss = hyperlink_score_loss(y_pred, y)
    loss.backward()
    optimizer.step()

def predict(G,feature,node_fea, incidence_matrix, model):
    model.eval()
    with torch.no_grad():
        y_pred = model(G,feature, node_fea,incidence_matrix)
    return torch.squeeze(y_pred)
def create_neg_incidence_matrix_new(incidence_matrix):
    incidence_matrix_neg = torch.zeros(incidence_matrix.shape)
    a=0.5
    for i, edge in enumerate(incidence_matrix.T):
        nodes = torch.where(edge)[0]
        nodes_comp = torch.tensor(list(set(range(len(incidence_matrix))) - set(nodes.tolist())))
        edge_neg_l = torch.tensor(np.random.choice(nodes, math.floor(len(nodes) * a), replace=False))
        edge_neg_r = torch.tensor(np.random.choice(nodes_comp, len(nodes) - math.floor(len(nodes) * a), replace=False))
        incidence_matrix_neg[edge_neg_l, i] = incidence_matrix[edge_neg_l,i]
        z=torch.sum(incidence_matrix[edge_neg_l,i])
        if z>0:
            edge_neg_r = edge_neg_r.tolist()
            edge_neg_r1 = np.random.choice(edge_neg_r, math.floor(len(edge_neg_r) * 0.5), replace=False)
            edge_neg_r2 = torch.tensor(list(set(edge_neg_r) - set(edge_neg_r1.tolist())))
            edge_neg_r1 = torch.tensor(edge_neg_r1 , dtype=torch.long)
            edge_neg_r2 = torch.tensor(edge_neg_r2, dtype=torch.long)
            incidence_matrix_neg[edge_neg_r1, i] = -1
            incidence_matrix_neg[edge_neg_r2, i] = 1
        else:
            edge_neg_r = edge_neg_r.tolist()
            edge_neg_r1 = np.random.choice(edge_neg_r, math.floor(len(edge_neg_r) * 0.5), replace=False)
            edge_neg_r2 = torch.tensor(list(set(edge_neg_r) - set(edge_neg_r1.tolist())))
            edge_neg_r1 = torch.tensor(edge_neg_r1, dtype=torch.long)
            edge_neg_r2 = torch.tensor(edge_neg_r2, dtype=torch.long)
            incidence_matrix_neg[edge_neg_r1, i] = 1
            incidence_matrix_neg[edge_neg_r2, i] = -1
    return incidence_matrix_neg
def get_prediction_score(name):
    path = './data/' + name
    namelist = get_filenames(path)
    universe_pool = cobra.io.read_sbml_model('./data/pools/bigg_universe.xml')
    top = []
    for sample in namelist:
        if sample=='iCHOv1.xml':
            print(sample)
            universe_pool_copy = universe_pool.copy()
            rxn_df, rxn_pool_df = get_data_from_pool2(path, sample, universe_pool_copy)
            print(rxn_df.shape),print(rxn_pool_df.shape)
            incidence_matrix_pos = rxn_df.to_numpy()
            ###############################################
            incidence_matrix_pos = torch.tensor(incidence_matrix_pos, dtype=torch.float)
            #incidence_matrix_pos = torch.where(incidence_matrix_pos > 0, torch.tensor(1), torch.tensor(-1))
            incidence_matrix_pos = torch.where(incidence_matrix_pos > 0, torch.tensor(1), torch.where(incidence_matrix_pos < 0, torch.tensor(-1), torch.tensor(0)))
            incidence_matrix_pos = torch.unique(incidence_matrix_pos, dim=1)
            incidence_matrix_pos = torch.tensor(incidence_matrix_pos, dtype=torch.float)
            ###############################################
            #train_data=incidence_matrix_pos
            incidence_matrix_cand = rxn_pool_df.to_numpy()
            incidence_matrix_cand = torch.tensor(incidence_matrix_cand, dtype=torch.float)
            incidence_matrix_cand = torch.where(incidence_matrix_cand > 0, torch.tensor(1), torch.where(incidence_matrix_cand < 0, torch.tensor(-1), torch.tensor(0)))
            incidence_matrix_neg = create_neg_incidence_matrix_new(incidence_matrix_pos)
            incidence_matrix_neg = torch.unique(incidence_matrix_neg, dim=1)
            test_index=np.random.choice(np.arange(0,incidence_matrix_pos.shape[1]),int(incidence_matrix_pos.shape[1]*0.4),replace=False)
            train_index=np.setdiff1d(np.arange(0,incidence_matrix_pos.shape[1]),test_index)
            train_pos,train_neg=incidence_matrix_pos[:,train_index],incidence_matrix_neg[:,train_index]
            test_pos,test_neg=incidence_matrix_pos[:,test_index],incidence_matrix_neg[:,test_index]
            y_train = create_label(train_pos, train_neg)
            incidence_train = torch.cat((train_pos, train_neg), dim=1)
            incidence_test = torch.cat((test_pos, test_neg), dim=1)
            train_feature=train_pos.to(device)
            train_feature= torch.unique(torch.abs(train_feature),dim=1)
            zz=train_pos.clone().cpu().numpy()
            zz[zz<=0]=0
            zz[zz>0]=1
            print(np.sum(zz))
            G_test1=torch.from_numpy(zz).float()
            zz1=train_pos.clone().cpu().numpy()
            zz1[zz1>=0]=0
            zz1[zz1<0]=1
            G_test2=torch.from_numpy(zz1).float()
            G_test=(G_test1.to(device),G_test2.to(device))
            model = dshnet(input_dim=train_feature.shape,node_dim=(G_test[0].shape[1],G_test[1].shape[1]), emb_dim=args.emb_dim, conv_dim=args.conv_dim)
            model = model.to(device)
            optimizer = torch.optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
            node_fea=1
            for z in tqdm(range(35)):             
                train(G_test,train_feature.to(device), node_fea,y_train.to(device), incidence_train.to(device), model, optimizer)
            score = predict(G_test,train_feature.to(device), node_fea, incidence_test.to(device), model)
 